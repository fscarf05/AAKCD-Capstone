"""charts.py - the dashboard's graphs, drawn as SVG on the server.

No chart library and nothing loaded from the internet: each function returns
SVG markup the templates insert as is. Every piece of text that came from an
alert (file paths, commands, IPs) is HTML-escaped, so an attacker-chosen file
name cannot inject anything into the page.

Colours are CSS classes (.s-<stage>) defined in static/dashboard.css, so light
and dark mode each use their own validated steps.
"""
from __future__ import annotations

import math
import statistics
from collections import Counter
from datetime import datetime, timezone

from markupsafe import Markup, escape

import stats

STAGES = stats.STAGE_ORDER
LABELS = {
    "reconnaissance": "Reconnaissance", "delivery": "Delivery", "exploitation": "Exploitation",
    "installation": "Installation", "command_control": "Command & control", "other": "Other (Wazuh)",
}
BUCKETS = [60, 120, 300, 600, 900, 1800, 3600, 7200, 21600, 43200, 86400]


def _stage(name):
    return name if name in STAGES else "other"


def _nice(value):
    """Round an axis maximum up to 1, 2 or 5 times a power of ten."""
    if value <= 0:
        return 1
    power = 10 ** math.floor(math.log10(value))
    for step in (1, 2, 5, 10):
        if value <= step * power:
            return step * power
    return 10 * power


def _clock(epoch, with_date=False):
    when = datetime.fromtimestamp(epoch, tz=timezone.utc)
    return when.strftime("%d %b %H:%M") if with_date else when.strftime("%H:%M")


def _secs(value):
    return f"{value:.0f} s" if value < 120 else f"{value / 60:.1f} min"


def _top_rounded(x, y, w, h, r=4):
    """A bar whose top corners are rounded and whose base sits square on the axis."""
    r = min(r, w / 2, h)
    return (f"M{x:.1f},{y + h:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} "
            f"H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} V{y + h:.1f} Z")


def _right_rounded(x, y, w, h, r=4):
    r = min(r, h / 2, w)
    return (f"M{x:.1f},{y:.1f} H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} "
            f"V{y + h - r:.1f} Q{x + w:.1f},{y + h:.1f} {x + w - r:.1f},{y + h:.1f} H{x:.1f} Z")


def legend(stages):
    items = "".join(f'<span class="key"><span class="sw s-{s}"></span>{escape(LABELS[s])}</span>' for s in stages)
    return Markup(f'<div class="legend">{items}</div>')


# ------------------------------------------------------------------ activity over time
def activity(incidents, responses, width=760, height=240):
    """Stacked columns: alerts per time bucket, coloured by kill chain stage,
    with a marker under the axis for each response sent."""
    points = [(stats.parse_time(a["timestamp"]), _stage(a.get("kill_chain_stage")))
              for i in incidents for a in i["alerts"]]
    points = [(t.timestamp(), s) for t, s in points if t]
    if not points:
        return None
    t0, t1 = min(p[0] for p in points), max(p[0] for p in points)
    bucket = next((b for b in BUCKETS if (t1 - t0) / b <= 36), BUCKETS[-1])
    start = math.floor(t0 / bucket) * bucket
    n = int((t1 - start) // bucket) + 1
    columns = [Counter() for _ in range(n)]
    for t, s in points:
        columns[int((t - start) // bucket)][s] += 1

    left, right, top, bottom = 36, 8, 12, 46
    plot_w, plot_h = width - left - right, height - top - bottom
    ymax = _nice(max(sum(c.values()) for c in columns))
    col = plot_w / n
    bar_w = min(28.0, col * 0.7)
    order = STAGES + ["other"]
    out = [f'<svg class="chart" viewBox="0 0 {width} {height}" role="img" '
           f'aria-label="Alerts over time, stacked by kill chain stage">']
    for frac in (0, 0.5, 1):   # recessive grid: zero, half and top
        y = top + plot_h * (1 - frac)
        out.append(f'<line class="grid" x1="{left}" x2="{width - right}" y1="{y:.1f}" y2="{y:.1f}"/>')
        out.append(f'<text class="axis" x="{left - 6}" y="{y + 4:.1f}" text-anchor="end">{ymax * frac:g}</text>')
    for i, counts in enumerate(columns):
        total = sum(counts.values())
        if not total:
            continue
        x = left + i * col + (col - bar_w) / 2
        y = top + plot_h
        present = [s for s in order if counts[s]]
        for k, s in enumerate(present):
            h = plot_h * counts[s] / ymax
            gap = 2 if k else 0                     # 2px surface gap between stacked segments
            seg_y, seg_h = y - h, max(h - gap, 1)
            if k == len(present) - 1:
                out.append(f'<path class="s-{s}" d="{_top_rounded(x, seg_y, bar_w, seg_h)}"/>')
            else:
                out.append(f'<rect class="s-{s}" x="{x:.1f}" y="{seg_y:.1f}" width="{bar_w:.1f}" height="{seg_h:.1f}"/>')
            y -= h
        parts = ", ".join(f"{LABELS[s]} {counts[s]}" for s in present)
        tip = f"{_clock(start + i * bucket)}–{_clock(start + (i + 1) * bucket)} · {total} alert{'s' if total != 1 else ''}: {parts}"
        out.append(f'<rect class="hit" x="{left + i * col:.1f}" y="{top}" width="{col:.1f}" height="{plot_h}" '
                   f'data-tip="{escape(tip)}"/>')
    base = top + plot_h
    out.append(f'<line class="baseline" x1="{left}" x2="{width - right}" y1="{base}" y2="{base}"/>')
    for r in responses:   # response markers under the axis
        sent = stats.parse_time(r.get("time"))
        if not sent:
            continue
        x = left + (sent.timestamp() - start) / (n * bucket) * plot_w
        if not left <= x <= width - right:
            continue
        tip = f"Response at {_clock(sent.timestamp())}: {r.get('command')} → {r.get('target')} ({stats.outcome(r.get('result'))})"
        out.append(f'<path class="marker" d="M{x:.1f},{base + 4} l5,8 h-10 Z" data-tip="{escape(tip)}"/>')
    span_days = (n * bucket) > 86400
    for frac in (0, 0.5, 1):
        t = start + n * bucket * frac
        anchor = {0: "start", 0.5: "middle", 1: "end"}[frac]
        out.append(f'<text class="axis" x="{left + plot_w * frac:.1f}" y="{height - 8}" '
                   f'text-anchor="{anchor}">{_clock(t, span_days)}</text>')
    out.append("</svg>")
    used = [s for s in order if any(c[s] for c in columns)]
    return {"svg": Markup("".join(out)), "legend": legend(used),
            "bucket": _secs(bucket), "has_responses": bool(responses)}


# ------------------------------------------------------------------ response times
def response_times(rows, width=760, row_h=26):
    """Horizontal bars, one per response, in the order they were sent, with the median marked.

    A square-root x-scale keeps a fast response (seconds) visible next to a slow
    one (minutes); a linear scale would crush all the quick bars against zero.
    """
    if not rows:
        return None
    rows = sorted(rows, key=lambda r: r["sent_at"] or "")
    label_w, right, top, head = 210, 72, 8, 20
    plot_top = top + head                       # a band above the bars for the median label
    height = plot_top + row_h * len(rows) + 30
    base = height - 22
    plot_w = width - label_w - right
    xmax = max([r["seconds"] for r in rows] + [1])
    root = math.sqrt(xmax)
    xpos = lambda v: label_w + (math.sqrt(max(v, 0.0)) / root) * plot_w
    timed = [r["seconds"] for r in rows if r["outcome"] in ("sent", "dry run")]
    median = statistics.median(timed) if timed else None
    out = [f'<svg class="chart" viewBox="0 0 {width} {height}" role="img" aria-label="Time to respond, one bar per response">']
    for frac in (0, 0.25, 0.5, 0.75, 1.0):       # ticks evenly spaced on the sqrt scale
        x = label_w + frac * plot_w
        out.append(f'<line class="grid" x1="{x:.1f}" x2="{x:.1f}" y1="{plot_top}" y2="{base}"/>')
        out.append(f'<text class="axis" x="{x:.1f}" y="{base + 16}" text-anchor="middle">{_secs(frac * frac * xmax)}</text>')
    for k, r in enumerate(rows):
        y = plot_top + k * row_h
        w = max(xpos(r["seconds"]) - label_w, 2)
        good = r["outcome"] in ("sent", "dry run")
        label = f"#{r['incident_id']} {LABELS.get(r['stage'], r['stage'])}"
        tip = f"{label}: {r['command']} → {r['target']} · {r['outcome']} after {_secs(r['seconds'])}"
        out.append(f'<text class="label" x="{label_w - 8}" y="{y + 17}" text-anchor="end">{escape(label)}</text>')
        out.append(f'<path class="{"bar" if good else "bar-muted"}" d="{_right_rounded(label_w, y + 5, w, 14)}" data-tip="{escape(tip)}"/>')
        value = _secs(r["seconds"]) + ("" if good else f" · {r['outcome']}")
        out.append(f'<text class="value" x="{label_w + w + 6:.1f}" y="{y + 17}">{escape(value)}</text>')
    if median is not None:
        x = min(max(xpos(median), label_w + 30), width - right - 30)
        out.append(f'<line class="median" x1="{x:.1f}" x2="{x:.1f}" y1="{plot_top}" y2="{base}"/>')
        out.append(f'<text class="axis strong" x="{x:.1f}" y="{top + 13}" text-anchor="middle">median {_secs(median)}</text>')
    out.append("</svg>")
    return Markup("".join(out))


# ------------------------------------------------------------------ alerts grouped into incidents
def grouping(incidents, limit=10):
    """Bars of how many alerts each incident absorbed, largest first."""
    rows = sorted(incidents, key=lambda i: len(i["alerts"]), reverse=True)[:limit]
    peak = max([len(i["alerts"]) for i in rows] + [1])
    return [{"id": i["id"], "key": i.get("identifier_value"), "severity": i.get("severity"),
             "alerts": len(i["alerts"]), "pct": round(100 * len(i["alerts"]) / peak, 1)} for i in rows]


# ------------------------------------------------------------------ one incident's timeline
def incident_timeline(incident, response_rows, width=760, lane_h=34):
    """Each alert as a dot on its stage's lane; each response as a diamond on the same lane."""
    alerts = [(stats.parse_time(a["timestamp"]), _stage(a.get("kill_chain_stage")), a) for a in incident["alerts"]]
    alerts = [(t.timestamp(), s, a) for t, s, a in alerts if t]
    resp = [(stats.parse_time(r["sent_at"]), r) for r in response_rows]
    resp = [(t.timestamp(), r) for t, r in resp if t]
    if not alerts:
        return None
    lanes = [s for s in STAGES + ["other"] if any(s == st for _, st, _ in alerts)
             or any(_stage(r["stage"]) == s for _, r in resp)]
    times = [t for t, _, _ in alerts] + [t for t, _ in resp]
    t0, t1 = min(times), max(times)
    pad = max((t1 - t0) * 0.04, 5)
    t0, t1 = t0 - pad, t1 + pad
    label_w, right, top = 150, 16, 8
    height = top + lane_h * len(lanes) + 28
    plot_w = width - label_w - right
    xpos = lambda t: label_w + (t - t0) / (t1 - t0) * plot_w
    out = [f'<svg class="chart" viewBox="0 0 {width} {height}" role="img" aria-label="Incident timeline by kill chain stage">']
    for k, s in enumerate(lanes):
        y = top + k * lane_h + lane_h / 2
        out.append(f'<line class="grid" x1="{label_w}" x2="{width - right}" y1="{y:.1f}" y2="{y:.1f}"/>')
        out.append(f'<text class="label" x="{label_w - 10}" y="{y + 4:.1f}" text-anchor="end">{escape(LABELS[s])}</text>')
    for t, s, a in alerts:
        y = top + lanes.index(s) * lane_h + lane_h / 2
        tip = f"{_clock(t)} · {a.get('source_agent')} · {str(a.get('summary', ''))[:140]}"
        out.append(f'<circle class="dot s-{s}" cx="{xpos(t):.1f}" cy="{y:.1f}" r="5.5" data-tip="{escape(tip)}"/>')
    for t, r in resp:
        y = top + lanes.index(_stage(r["stage"])) * lane_h + lane_h / 2
        x = xpos(t)
        tip = f"Response {_clock(t)}: {r['command']} → {r['target']} · {r['outcome']} after {_secs(r['seconds'])}"
        out.append(f'<path class="diamond" d="M{x:.1f},{y - 8:.1f} l8,8 l-8,8 l-8,-8 Z" data-tip="{escape(tip)}"/>')
    base = height - 22
    for frac in (0, 0.5, 1):
        t = t0 + (t1 - t0) * frac
        anchor = {0: "start", 0.5: "middle", 1: "end"}[frac]
        out.append(f'<text class="axis" x="{label_w + plot_w * frac:.1f}" y="{base + 16}" '
                   f'text-anchor="{anchor}">{datetime.fromtimestamp(t, tz=timezone.utc).strftime("%H:%M:%S")}</text>')
    out.append("</svg>")
    return Markup("".join(out))
