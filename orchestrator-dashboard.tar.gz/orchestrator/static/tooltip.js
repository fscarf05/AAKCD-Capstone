// One shared tooltip for any element with data-tip (bars, tiles).
(() => {
  const tip = document.createElement("div");
  tip.id = "tip"; tip.setAttribute("role", "tooltip");
  document.body.appendChild(tip);
  document.addEventListener("pointermove", (e) => {
    const el = e.target.closest("[data-tip]");
    if (!el) { tip.style.opacity = 0; return; }
    tip.textContent = el.dataset.tip;
    tip.style.left = Math.min(e.clientX + 12, innerWidth - tip.offsetWidth - 8) + "px";
    tip.style.top = (e.clientY + 14) + "px";
    tip.style.opacity = 1;
  });

  // Make a whole table row clickable (the #id link still works on its own).
  document.addEventListener("click", (e) => {
    if (e.target.closest("a")) return;            // let real links behave normally
    const row = e.target.closest("tr.rowlink");
    if (row && row.dataset.href) location.href = row.dataset.href;
  });
})();
