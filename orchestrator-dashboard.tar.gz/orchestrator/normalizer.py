# normalizer.py - turns any alert from Wazuh into one consistent shape.
#
# Two kinds of alert arrive:
#   1. Wazuh's own built-in alerts (e.g. SSH login failures). Their details
#      live in rule.* and data.srcip.
#   2. Our team's detection agents' alerts, written in the shared AAKCD
#      schema. Wazuh's JSON decoder puts every field under data.*
#      (data.stage, data.severity, data.evidence.file_path, ...).
#
# Everything after this file only ever sees the normalised shape.

STAGES = {"reconnaissance", "delivery", "exploitation",
          "installation", "command_control"}

# Maps Wazuh's MITRE ATT&CK tactics onto our five kill chain stages.
TACTIC_TO_STAGE = {
    "Reconnaissance": "reconnaissance",
    "Discovery": "reconnaissance",
    "Initial Access": "delivery",
    "Execution": "exploitation",
    "Credential Access": "exploitation",
    "Privilege Escalation": "exploitation",
    "Defense Evasion": "exploitation",
    "Lateral Movement": "exploitation",
    "Persistence": "installation",
    "Command and Control": "command_control",
}


def _confidence_from_level(level):
    """Wazuh rule levels run 0-15. Bucket them into our three words."""
    if level >= 10:
        return "high"
    if level >= 5:
        return "medium"
    return "low"


def _stage_from_tactics(tactics):
    for tactic in tactics:
        if tactic in TACTIC_TO_STAGE:
            return TACTIC_TO_STAGE[tactic]
    return "unknown"


def _is_team_alert(data):
    return "stage" in data and "severity" in data


def normalize(raw):
    """Return the normalised alert, or None if it should be ignored."""
    rule = raw.get("rule", {})
    data = raw.get("data") or {}
    agent = raw.get("agent", {})

    # Ignore the alerts Wazuh raises about our own responses (for example
    # "Host Blocked by firewall-drop"), so a response never feeds back in.
    if "active_response" in rule.get("groups", []):
        return None

    if _is_team_alert(data):
        stage = str(data.get("stage", "")).lower()
        if stage not in STAGES:
            stage = "unknown"
        source_agent = data.get("agent", "unknown")
        confidence = str(data.get("confidence", "low")).lower()
        mitre_technique = data.get("mitre_technique_id", "unknown")
        summary = data.get("description", "No description provided")
        source_ip = data.get("source_ip")
        evidence = data.get("evidence") or {}
        # Display only: shown on the dashboard, never used by the responder.
        ai = {k: data[k] for k in ("ai_status", "ai_summary", "ai_recommended_actions") if data.get(k)}
        detected_at = data.get("timestamp")   # when the agent saw it (Wazuh's timestamp is when it arrived)
    else:
        level = int(rule.get("level", 0))
        mitre = rule.get("mitre", {})
        stage = _stage_from_tactics(mitre.get("tactic", []))
        source_agent = f"wazuh-rule-{rule.get('id', '?')}"
        confidence = _confidence_from_level(level)
        mitre_ids = mitre.get("id", [])
        mitre_technique = mitre_ids[0] if mitre_ids else "unknown"
        summary = rule.get("description", "No description provided")
        source_ip = data.get("srcip")
        evidence = {}
        ai, detected_at = {}, None

    if confidence not in ("low", "medium", "high"):
        confidence = "low"

    # Group by attacker IP when we have one, otherwise by the machine.
    if source_ip:
        identifier_type, identifier_value = "source_ip", source_ip
    else:
        identifier_type = "host"
        identifier_value = agent.get("name", "unknown")

    return {
        "wazuh_id": raw.get("id"),
        "timestamp": raw.get("@timestamp"),
        "agent_id": agent.get("id"),
        "agent_name": agent.get("name"),
        "source_agent": source_agent,
        "kill_chain_stage": stage,
        "mitre_technique": mitre_technique,
        "summary": summary,
        "confidence": confidence,
        "rule_id": rule.get("id"),
        "rule_level": rule.get("level"),
        "source_ip": source_ip,
        "evidence": evidence,
        "identifier_type": identifier_type,
        "identifier_value": identifier_value,
        "detected_at": detected_at,
        **ai,
    }
