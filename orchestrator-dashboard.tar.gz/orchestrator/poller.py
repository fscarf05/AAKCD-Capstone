# poller.py - the Response Orchestrator's main loop.
#
# Every POLL_SECONDS:
#   1. fetch new alerts from the Wazuh indexer
#   2. normalise them into one shape
#   3. correlate them into incidents
#   4. close incidents that have gone quiet
#   5. decide and carry out responses for open, serious incidents
#
# Run with:  python3 poller.py        (Ctrl+C to stop)
import json
import os
import time
from datetime import datetime, timezone

import config
import correlator
import normalizer
import responder
import wazuh_client

CHECKPOINT_FILE = "checkpoint.json"


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def load_checkpoint():
    """The timestamp of the last alert we processed. On a first run we
    start from 'now', so old alerts are never acted on as if they were new."""
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE) as f:
            return json.load(f)["last_seen"]
    start = now_iso()
    save_checkpoint(start)
    return start


def save_checkpoint(ts):
    with open(CHECKPOINT_FILE, "w") as f:
        json.dump({"last_seen": ts}, f)


def keep_alert(raw):
    """True if this raw Wazuh alert should enter correlation. Drops known-noisy
    host-keeping rules (config.IGNORE_RULES) and anything below MIN_RULE_LEVEL."""
    rule = raw.get("rule", {})
    if str(rule.get("id", "")) in getattr(config, "IGNORE_RULES", set()):
        return False
    return int(rule.get("level", 0)) >= config.MIN_RULE_LEVEL


def poll_once():
    """Run one cycle. Returns how many raw alerts it fetched."""
    checkpoint = load_checkpoint()
    raw_alerts = wazuh_client.fetch_alerts_since(checkpoint)
    if not raw_alerts:
        return 0

    alerts = []
    for raw in raw_alerts:
        if not keep_alert(raw):
            continue
        alert = normalizer.normalize(raw)
        if alert:
            alerts.append(alert)

    incidents = correlator.load_incidents()
    incidents, touched = correlator.correlate(alerts, incidents)

    # Close quiet incidents BEFORE responding, so we never act on stale ones.
    incidents, newly_closed = correlator.close_expired(incidents)
    correlator.archive_closed(newly_closed)
    open_ids = {i["id"] for i in incidents}

    for incident in touched:
        if incident["id"] not in open_ids:
            print(f"\n=== incident #{incident['id']} "
                  f"[{incident['identifier_type']}={incident['identifier_value']}] "
                  f"closed straight away (its alerts were already old)")
            continue

        print(f"\n=== incident #{incident['id']} "
              f"[{incident['identifier_type']}={incident['identifier_value']}] "
              f"severity={incident['severity']} alerts={len(incident['alerts'])} "
              f"stages={incident['stages']} agents={incident['agent_ids']}")
        for a in incident["alerts"][-3:]:
            print(f"  - {a['timestamp']} {a['source_agent']}: {a['summary']} "
                  f"({a['confidence']})")

        for action in responder.decide(incident):
            responder.execute(incident, action)

    correlator.save_incidents(incidents)
    save_checkpoint(raw_alerts[-1]["@timestamp"])
    return len(raw_alerts)


def main():
    mode = "DRY RUN (deciding only)" if config.DRY_RUN else "LIVE (enforcing responses)"
    print(f"AAKCD Response Orchestrator started: {mode}")
    print(f"Polling {config.INDEXER_URL} every {config.POLL_SECONDS}s\n")
    while True:
        try:
            fetched = poll_once()
        except Exception as err:
            # A Wazuh restart or network blip should never kill the loop.
            print(f"[{now_iso()}] poll failed: {err}")
            fetched = 0
        if fetched >= 100:
            continue  # a full page came back, so fetch the rest straight away
        if fetched == 0:
            print(f"[{now_iso()}] no new alerts")
        time.sleep(config.POLL_SECONDS)


if __name__ == "__main__":
    main()
