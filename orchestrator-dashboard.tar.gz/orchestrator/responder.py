# responder.py - the playbook. Decides which response each incident gets,
# checks the safety rules, and asks Wazuh to carry the response out.
#
# Rules decide; scripts on the victim execute. No AI makes or carries out
# a response, so every action is predictable and explainable.
import ipaddress
import json
import os
from datetime import datetime, timezone

import config
import wazuh_client

RESPONSES_FILE = "responses.json"

# For each kill chain stage: the responses to try, best first, and the
# piece of evidence each one needs. For each alert, the first response whose
# evidence that alert carries (and whose script is installed) wins.
PLAYBOOK = {
    "reconnaissance":  [("firewall-drop", "source_ip")],
    "delivery":        [("quarantine-file", "file_path"),
                        ("firewall-drop", "source_ip")],
    "exploitation":    [("kill-process", "process_id"),
                        ("firewall-drop", "source_ip")],
    "installation":    [("quarantine-file", "file_path"),
                        ("disable-account", "username")],
    "command_control": [("block-outbound", "destination_ip")],
}

# These ship with Wazuh. Everything else is one of our custom scripts.
BUILT_IN = {"firewall-drop", "disable-account"}

# Folders a quarantine must never touch, whatever the alert says.
PROTECTED_PATHS = ("/bin", "/sbin", "/usr", "/lib", "/etc", "/boot", "/var/ossec")
PROTECTED_USERS = {"root", "wazuh"}


def _evidence_for(alert, field):
    """The value a response needs from one alert, plus its evidence block."""
    evidence = alert.get("evidence") or {}
    value = alert.get("source_ip") if field == "source_ip" else evidence.get(field)
    return (None, None) if value in (None, "") else (value, evidence)


def _safety_check(command, value):
    """Return a reason to refuse, or None if the response is safe."""
    if command in ("firewall-drop", "block-outbound"):
        if value in config.ALLOWLIST:
            return f"{value} is on the allowlist"
        try:
            ip = ipaddress.ip_address(value)
        except ValueError:
            return f"{value} is not a valid IP address"
        # Shared or local addresses are never one attacker: blocking them
        # breaks normal networking (device discovery, broadcasts, the host itself).
        if ip.is_multicast or ip.is_loopback or ip.is_unspecified or ip.is_link_local \
                or str(ip).endswith(".255"):
            return f"{value} is a multicast, broadcast or local address"
    if command == "quarantine-file" and str(value).startswith(PROTECTED_PATHS):
        return f"{value} is in a protected system folder"
    if command == "disable-account" and value in PROTECTED_USERS:
        return f"account {value} is protected"
    return None


def decide(incident):
    """Return the responses this incident needs right now (may be empty).

    Each alert gets the first playbook response its own evidence supports,
    so a response only ever acts on evidence from its own stage. Each
    target (e.g. one file, one account, one IP) is acted on once per
    incident, but two different targets in the same stage, such as a new
    account and a new cron job, both get a response."""
    if incident["severity"] not in config.RESPOND_AT:
        return []

    done = set(incident.setdefault("responded_targets", []))
    planned, actions, covered = set(), [], set()
    for alert in incident["alerts"]:
        stage = alert["kill_chain_stage"]
        if stage not in PLAYBOOK:
            continue
        chosen = None
        for command, field in PLAYBOOK[stage]:
            if command not in config.INSTALLED_RESPONSES:
                continue
            value, evidence = _evidence_for(alert, field)
            if value is not None:
                chosen = (command, field, value, evidence)
                break
        if chosen is None:
            continue
        covered.add(stage)
        command, field, value, evidence = chosen
        target = f"{command}:{value}"
        if target in done or target in planned:
            continue
        planned.add(target)
        actions.append({"stage": stage, "command": command, "field": field,
                        "value": value, "evidence": evidence, "target": target})

    # Fan-out cap: a real attacker uses a few servers, files or accounts. When
    # one stage asks to act on more targets than that, it is almost always a
    # false positive (e.g. routine traffic to many servers looking like
    # beaconing), so hold that stage for an analyst instead of firing at all.
    cap = getattr(config, "MAX_TARGETS_PER_STAGE", 5)
    held = incident.setdefault("held_stages", [])
    blocked_stages = set()
    for stage in {a["stage"] for a in actions}:
        new = sum(1 for a in actions if a["stage"] == stage)
        commands = {c for c, _ in PLAYBOOK[stage]}
        prior = sum(1 for t in done if t.split(":", 1)[0] in commands)
        if prior + new > cap:
            blocked_stages.add(stage)
            if stage not in held:
                held.append(stage)
                print(f"  [HELD] incident #{incident['id']} stage '{stage}': {prior + new} targets "
                      f"exceeds the cap of {cap}; likely a false positive, needs an analyst")
    actions = [a for a in actions if a["stage"] not in blocked_stages]

    # Log a stage with no usable evidence once, then wait in case it arrives.
    for stage in incident["stages"]:
        if (stage in PLAYBOOK and stage not in covered
                and stage not in incident["responded_stages"]
                and stage not in incident["skipped_stages"]):
            incident["skipped_stages"].append(stage)
            print(f"  [NO ACTION] incident #{incident['id']} stage "
                  f"'{stage}': no installed response has the evidence it needs")
    return actions


def _alert_data(action):
    """Build the data the script on the victim will read. Built-in Wazuh
    scripts read fixed fields; our custom scripts get the whole evidence
    block, so they can run their own safety checks (e.g. process_name)."""
    command, value = action["command"], action["value"]
    if command == "firewall-drop":
        return {"srcip": value}
    if command == "disable-account":
        return {"dstuser": value}
    evidence = dict(action.get("evidence") or {})
    evidence[action["field"]] = value
    return {"evidence": evidence}


def execute(incident, action):
    """Carry out one response on every machine involved in the incident."""
    command, value = action["command"], action["value"]
    refusal = _safety_check(command, value)

    record = {
        "time": datetime.now(timezone.utc).isoformat(),
        "incident_id": incident["id"],
        "severity": incident["severity"],
        "stage": action["stage"],
        "command": command,
        "target": value,
        "agents": incident["agent_ids"],
        "dry_run": config.DRY_RUN,
    }

    if refusal:
        record["result"] = f"refused: {refusal}"
    elif config.DRY_RUN:
        record["result"] = "dry run: not sent"
    else:
        results = []
        for agent_id in incident["agent_ids"]:
            try:
                reply = wazuh_client.run_active_response(
                    agent_id, command,
                    _alert_data(action),
                    custom=command not in BUILT_IN)
                failed = reply.get("data", {}).get("total_failed_items", 0)
                results.append(f"agent {agent_id}: {'failed' if failed else 'sent'}")
            except Exception as err:   # network or API error
                results.append(f"agent {agent_id}: error {err}")
        record["result"] = "; ".join(results)

    # Mark the target done unless every send errored, so we can retry later.
    if "error" not in record["result"] or "sent" in record["result"]:
        incident.setdefault("responded_targets", []).append(action["target"])
        if action["stage"] not in incident["responded_stages"]:
            incident["responded_stages"].append(action["stage"])

    _append_record(record)
    print(f"  [RESPONSE] incident #{incident['id']} {action['stage']}: "
          f"{command} {value} -> {record['result']}")
    return record


def _append_record(record):
    history = []
    if os.path.exists(RESPONSES_FILE):
        with open(RESPONSES_FILE) as f:
            history = json.load(f)
    history.append(record)
    with open(RESPONSES_FILE, "w") as f:
        json.dump(history, f, indent=2)
