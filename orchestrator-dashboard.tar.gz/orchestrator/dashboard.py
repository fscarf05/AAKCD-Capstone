"""dashboard.py - the AAKCD web dashboard: incidents, statistics and summaries.

Read-only: it reads the orchestrator's files and never changes a response.
Statistics come from stats.py (calculated, no AI). Incident summaries come
from summarizer.py (Groq, cached; a rule-based summary when AI is off).

    python3 dashboard.py --host 100.102.87.60          # then open http://100.102.87.60:8080
    python3 dashboard.py --folder demo/                # browse demo data instead

It has no login, so bind it to the Tailscale address (or 127.0.0.1), never
to every interface.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

from flask import Flask, abort, jsonify, render_template

import charts
import stats
import summarizer

HERE = Path(__file__).resolve().parent
STAGE_LABELS = {
    "reconnaissance": "Reconnaissance", "delivery": "Delivery", "exploitation": "Exploitation",
    "installation": "Installation", "command_control": "Command & control", "unknown": "Other",
}


def create_app(folder=HERE, allow_ai=True):
    app = Flask(__name__, template_folder=str(HERE / "templates"), static_folder=str(HERE / "static"))
    app.config.update(FOLDER=Path(folder), ALLOW_AI=allow_ai)

    @app.template_filter("clock")
    def clock(ts):
        when = stats.parse_time(ts)
        return when.strftime("%d %b %H:%M:%S") if when else "-"

    @app.template_filter("stage")
    def stage(name):
        return STAGE_LABELS.get(name, name or "-")

    @app.template_filter("secs")
    def secs(value):
        if value is None:
            return "-"
        return f"{value:.0f} s" if value < 120 else f"{value / 60:.1f} min"

    @app.context_processor
    def kill_chain_order():
        return {"stage_order": stats.STAGE_ORDER}

    def data():
        return stats.load_data(app.config["FOLDER"])

    @app.route("/")
    def overview():
        incidents, responses = data()
        figures = stats.compute(incidents, responses)
        peak = max([r["alerts"] for r in figures["alerts"]["by_stage"]] + [1])
        return render_template("overview.html", s=figures, peak=peak, recent=incidents[:8], now=datetime.now(),
                               activity=charts.activity(incidents, responses),
                               times_chart=charts.response_times(figures["responses"]["rows"]),
                               grouping=charts.grouping(incidents))

    @app.route("/incidents")
    def incident_list():
        incidents, _ = data()
        return render_template("incidents.html", incidents=incidents, now=datetime.now())

    @app.route("/incident/<int:incident_id>")
    def incident_detail(incident_id):
        incidents, responses = data()
        incident = next((i for i in incidents if i["id"] == incident_id), None)
        if incident is None:
            abort(404)
        summary = summarizer.Summarizer(app.config["FOLDER"]).get(
            incident, responses, allow_ai=app.config["ALLOW_AI"])
        mine = [r for r in stats.response_times(incidents, responses) if r["incident_id"] == incident_id]
        return render_template("incident.html", i=incident, summary=summary, responses=mine, now=datetime.now(),
                               timeline=charts.incident_timeline(incident, mine),
                               timeline_legend=charts.legend([s for s in charts.STAGES + ["other"]
                                                              if s in {charts._stage(a.get("kill_chain_stage")) for a in incident["alerts"]}]))

    @app.route("/api/stats")
    def api_stats():
        return jsonify(stats.compute(*data()))

    return app


def main():
    parser = argparse.ArgumentParser(description="AAKCD dashboard")
    parser.add_argument("--host", default="127.0.0.1",
                        help="address to listen on: the Tailscale IP to reach it from your PC")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--folder", default=HERE, help="folder with the orchestrator's files")
    parser.add_argument("--no-ai", action="store_true", help="rule-based incident summaries only")
    args = parser.parse_args()
    if args.host in ("0.0.0.0", "::"):
        print("Warning: the dashboard has no login; listening on every interface exposes it to the whole network.")
    create_app(args.folder, allow_ai=not args.no_ai).run(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
