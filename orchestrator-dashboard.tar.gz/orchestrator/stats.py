"""stats.py - numbers about attacks and responses, calculated from the
orchestrator's own files. No AI is involved: every figure is computed, so it
is exact and repeatable.

Reads incidents.json (open), closed_incidents.json and responses.json from the
orchestrator folder.

    python3 stats.py          # print the statistics
    python3 stats.py --json   # the same as JSON (what the dashboard uses)

Response time ("time to respond") is measured from the first alert of the
stage a response acted on to the moment the orchestrator sent the response.
Detection delay is measured from when an agent saw something to when its alert
reached Wazuh (it needs the victim's clock to be in sync).
"""
from __future__ import annotations

import argparse
import json
import statistics
from collections import Counter
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGE_ORDER = ["reconnaissance", "delivery", "exploitation", "installation", "command_control"]
SEVERITY_ORDER = ["critical", "high", "medium", "low"]


def parse_time(ts):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except ValueError:
        return None


def _load(path, default):
    try:
        return json.loads(Path(path).read_text())
    except (FileNotFoundError, ValueError):
        return default


def load_data(folder=HERE):
    """Open and closed incidents (newest copy of each wins) plus the response log."""
    folder = Path(folder)
    by_id = {}
    for incident in _load(folder / "closed_incidents.json", []):
        by_id[incident["id"]] = {**incident, "status": "closed"}
    for incident in _load(folder / "incidents.json", []):
        by_id[incident["id"]] = {**incident, "status": "open"}
    incidents = sorted(by_id.values(), key=lambda i: i["id"], reverse=True)
    return incidents, _load(folder / "responses.json", [])


def outcome(result: str) -> str:
    """Group the responder's result text into a few outcomes."""
    text = (result or "").lower()
    if text.startswith("refused"):
        return "refused"
    if text.startswith("dry run"):
        return "dry run"
    if "sent" in text:
        return "sent"
    if "failed" in text:
        return "failed"
    return "error"


def _summary(values):
    values = [v for v in values if v is not None]
    if not values:
        return {"count": 0, "mean": None, "median": None, "min": None, "max": None}
    return {"count": len(values), "mean": round(statistics.mean(values), 1),
            "median": round(statistics.median(values), 1),
            "min": round(min(values), 1), "max": round(max(values), 1)}


def response_times(incidents, responses):
    """One row per response: how long after the stage's first alert it was sent."""
    by_id = {i["id"]: i for i in incidents}
    rows = []
    for record in responses:
        incident = by_id.get(record.get("incident_id"))
        sent_at = parse_time(record.get("time"))
        if incident is None or sent_at is None:
            continue
        stage_times = [parse_time(a["timestamp"]) for a in incident["alerts"]
                       if a.get("kill_chain_stage") == record.get("stage")]
        stage_times = [t for t in stage_times if t] or [parse_time(incident["alerts"][0]["timestamp"])]
        first = min(t for t in stage_times if t)
        rows.append({
            "incident_id": record["incident_id"],
            "stage": record.get("stage"),
            "command": record.get("command"),
            "target": record.get("target"),
            "outcome": outcome(record.get("result")),
            "seconds": round((sent_at - first).total_seconds(), 1),
            "sent_at": record.get("time"),
        })
    return rows


def detection_delays(incidents):
    """Seconds from an agent seeing something to its alert reaching Wazuh."""
    delays = []
    for incident in incidents:
        for alert in incident["alerts"]:
            seen, arrived = parse_time(alert.get("detected_at")), parse_time(alert.get("timestamp"))
            if seen and arrived:
                delays.append((arrived - seen).total_seconds())
    return delays


def compute(incidents, responses):
    alerts = [a for i in incidents for a in i["alerts"]]
    team_alerts = [a for a in alerts if not str(a.get("source_agent", "")).startswith("wazuh-rule-")]
    times = response_times(incidents, responses)
    sent_times = [r["seconds"] for r in times if r["outcome"] in ("sent", "dry run")]

    stage_counts = Counter(a.get("kill_chain_stage", "unknown") for a in alerts)
    by_stage = [{"stage": s, "alerts": stage_counts.get(s, 0)} for s in STAGE_ORDER]
    other = sum(n for s, n in stage_counts.items() if s not in STAGE_ORDER)

    severity_counts = Counter(i.get("severity", "low") for i in incidents)
    alerts_per_incident = [len(i["alerts"]) for i in incidents]

    first_response = []
    for incident in incidents:
        opened = parse_time(incident["alerts"][0]["timestamp"]) if incident["alerts"] else None
        sent = [parse_time(r.get("time")) for r in responses
                if r.get("incident_id") == incident["id"] and outcome(r.get("result")) in ("sent", "dry run")]
        sent = [t for t in sent if t]
        if opened and sent:
            first_response.append((min(sent) - opened).total_seconds())

    return {
        "incidents": {
            "total": len(incidents),
            "open": sum(1 for i in incidents if i.get("status") == "open"),
            "closed": sum(1 for i in incidents if i.get("status") == "closed"),
            "by_severity": [{"severity": s, "incidents": severity_counts.get(s, 0)} for s in SEVERITY_ORDER],
            "multi_stage": sum(1 for i in incidents if len(set(i.get("stages", [])) - {"unknown"}) >= 2),
        },
        "alerts": {
            "total": len(alerts),
            "from_team_agents": len(team_alerts),
            "from_wazuh_rules": len(alerts) - len(team_alerts),
            "per_incident": _summary(alerts_per_incident),
            # Alert fatigue: how many raw alerts each incident saved an analyst from reading separately
            "alerts_per_incident_ratio": round(len(alerts) / len(incidents), 1) if incidents else None,
            "by_stage": by_stage,
            "other_stage": other,
            "by_agent": Counter(str(a.get("source_agent")) for a in team_alerts).most_common(),
            "top_techniques": Counter(a.get("mitre_technique") for a in alerts
                                      if a.get("mitre_technique") not in (None, "unknown")).most_common(8),
            "top_sources": Counter(a.get("source_ip") for a in alerts if a.get("source_ip")).most_common(5),
            "with_ai_summary": sum(1 for a in alerts if a.get("ai_status") == "ok"),
        },
        "responses": {
            "total": len(responses),
            "by_outcome": Counter(outcome(r.get("result")) for r in responses).most_common(),
            "by_command": Counter(r.get("command") for r in responses).most_common(),
            "no_action_stages": sum(len(i.get("skipped_stages", [])) for i in incidents),
            "time_to_respond": _summary(sent_times),
            "time_to_first_response": _summary(first_response),
            "rows": times,
        },
        "detection_delay": _summary(detection_delays(incidents)),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="AAKCD attack and response statistics")
    parser.add_argument("--json", action="store_true", help="print JSON")
    parser.add_argument("--folder", default=HERE, help="orchestrator folder with the incident files")
    args = parser.parse_args(argv)
    result = compute(*load_data(args.folder))
    if args.json:
        print(json.dumps(result, indent=2, default=str))
        return
    inc, al, rs = result["incidents"], result["alerts"], result["responses"]
    print(f"Incidents: {inc['total']} ({inc['open']} open, {inc['closed']} closed, {inc['multi_stage']} multi-stage)")
    print("  by severity: " + ", ".join(f"{r['severity']} {r['incidents']}" for r in inc["by_severity"]))
    print(f"Alerts: {al['total']} ({al['from_team_agents']} from AAKCD agents, {al['from_wazuh_rules']} from Wazuh rules)")
    print(f"  per incident: {al['alerts_per_incident_ratio']} on average")
    print("  by stage: " + ", ".join(f"{r['stage']} {r['alerts']}" for r in al["by_stage"]))
    t = rs["time_to_respond"]
    print(f"Responses: {rs['total']} " + str(dict(rs["by_outcome"])))
    print(f"  time to respond: median {t['median']}s, mean {t['mean']}s, fastest {t['min']}s, slowest {t['max']}s")
    d = result["detection_delay"]
    print(f"Detection delay (agent -> Wazuh): median {d['median']}s over {d['count']} alerts")


if __name__ == "__main__":
    main()
