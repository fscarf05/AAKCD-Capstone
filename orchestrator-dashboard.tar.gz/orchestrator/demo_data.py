"""demo_data.py - write a realistic sample of orchestrator files into a folder,
so the statistics and dashboard can be tried without the lab running.

    python3 demo_data.py demo/          # then: python3 dashboard.py --folder demo/

It never touches the real incidents.json / responses.json unless you point it
at the orchestrator folder yourself. The data mirrors the lab tests: a port
scan from Kali, an SSH brute force, and one victim incident spanning delivery,
installation and command and control.
"""
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

START = datetime(2026, 10, 16, 21, 40, tzinfo=timezone.utc)


def ts(seconds):
    return (START + timedelta(seconds=seconds)).isoformat().replace("+00:00", "Z")


def alert(at, stage, agent, summary, confidence, technique, ip=None, evidence=None, delay=1.5, ai=None, level=10):
    team = not agent.startswith("wazuh-rule-")
    a = {
        "wazuh_id": f"w{at}", "timestamp": ts(at), "agent_id": "002", "agent_name": "victim",
        "source_agent": agent, "kill_chain_stage": stage, "mitre_technique": technique,
        "summary": summary, "confidence": confidence, "rule_id": "100102" if team else agent[11:],
        "rule_level": level, "source_ip": ip, "evidence": evidence or {},
        "identifier_type": "source_ip" if ip else "host", "identifier_value": ip or "victim",
        "detected_at": ts(at - delay) if team else None,
    }
    if ai:
        a.update(ai_status="ok", ai_summary=ai)
    return a


def incident(iid, alerts, severity, responded, skipped=(), closed=False):
    inc = {
        "id": iid, "identifier_type": alerts[0]["identifier_type"],
        "identifier_value": alerts[0]["identifier_value"], "agent_ids": ["002"],
        "stages": list(dict.fromkeys(a["kill_chain_stage"] for a in alerts)),
        "alerts": alerts, "responded_stages": responded, "responded_targets": [],
        "skipped_stages": list(skipped), "opened_at": alerts[0]["timestamp"],
        "correlated": len(alerts) > 1, "severity": severity,
    }
    if closed:
        inc["closed_at"] = ts(int((datetime.fromisoformat(alerts[-1]["timestamp"].replace("Z", "+00:00")) - START).total_seconds()) + 1800)
    return inc


def response(at, iid, stage, command, target, severity, result="agent 002: sent"):
    return {"time": (START + timedelta(seconds=at)).isoformat(), "incident_id": iid, "severity": severity,
            "stage": stage, "command": command, "target": target, "agents": ["002"],
            "dry_run": False, "result": result}


def build():
    scan = [
        alert(0, "reconnaissance", "recon", "192.168.79.132 probed 20 distinct targets within 60s.", "high", "T1595",
              ip="192.168.79.132", evidence={"scan_type": "vertical", "distinct_ports": 20}),
        alert(1, "reconnaissance", "recon", "192.168.79.132 probed 100 distinct targets within 60s.", "high", "T1595",
              ip="192.168.79.132", evidence={"scan_type": "vertical", "distinct_ports": 100},
              ai="A single host on the local network ran a fast vertical port scan against the victim. "
                 "Most connections were refused, which matches an automated scanner mapping open services."),
    ]
    brute = [alert(300 + i * 4, "exploitation", "wazuh-rule-5710", "sshd: Attempt to login using a non-existent user",
                   "medium", "T1110.001", ip="100.102.87.60", level=5) for i in range(6)]
    victim = [
        alert(600, "exploitation", "wazuh-rule-5402", "Successful sudo to ROOT executed.", "low", "T1548.003", level=3),
        alert(605, "delivery", "delivery", "Possible disguised malicious attachment detected: invoice2.pdf.exe",
              "high", "T1566.001", evidence={"file_path": "/home/victim/Downloads/invoice2.pdf.exe"}, delay=1.0),
        alert(700, "installation", "wazuh-rule-5902", "New user added to the system.", "medium", "T1136.001", level=8),
        alert(733, "installation", "installation", "A new local account 'backdoor1' (UID 1001) appeared on victim.",
              "high", "T1136.001", evidence={"username": "backdoor1"}, delay=1.2,
              ai="An account that can log in appeared outside change control. New local accounts are a common "
                 "way for an attacker to keep access after the initial compromise."),
        alert(900, "command_control", "command_control",
              "192.168.79.131 contacted 203.0.113.44:443 40 times at a near-constant 59.7 second interval.",
              "high", "T1573", evidence={"destination_ip": "203.0.113.44", "internal_host": "192.168.79.131"}, delay=2.0),
    ]
    incidents = [
        incident(1, scan, "critical", ["reconnaissance"], closed=True),
        incident(2, brute, "high", [], closed=True),
        incident(3, victim, "critical", ["delivery", "installation", "command_control"], skipped=["exploitation"]),
    ]
    responses = [
        response(16, 1, "reconnaissance", "firewall-drop", "192.168.79.132", "critical"),
        response(327, 2, "exploitation", "firewall-drop", "100.102.87.60", "high",
                 result="refused: 100.102.87.60 is on the allowlist"),
        response(619, 3, "delivery", "quarantine-file", "/home/victim/Downloads/invoice2.pdf.exe", "critical"),
        response(746, 3, "installation", "disable-account", "backdoor1", "critical"),
        response(914, 3, "command_control", "block-outbound", "203.0.113.44", "critical"),
    ]
    open_incidents = [i for i in incidents if "closed_at" not in i]
    closed = [i for i in incidents if "closed_at" in i]
    return open_incidents, closed, responses


def write(folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    open_incidents, closed, responses = build()
    (folder / "incidents.json").write_text(json.dumps(open_incidents, indent=2))
    (folder / "closed_incidents.json").write_text(json.dumps(closed, indent=2))
    (folder / "responses.json").write_text(json.dumps(responses, indent=2))
    return folder


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: python3 demo_data.py <folder>")
    print(f"Demo data written to {write(sys.argv[1])}")
