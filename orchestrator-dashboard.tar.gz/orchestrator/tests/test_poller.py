"""test_poller.py - the alert intake filter: noisy host rules are dropped,
low-level alerts are dropped, and real attack alerts are kept.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
import poller


def raw(rule_id, level):
    return {"rule": {"id": str(rule_id), "level": level}}


def test_noisy_host_rules_are_dropped():
    # dpkg, PAM session and rootcheck rules flood incidents without adding signal
    for rule_id in ("2901", "2902", "2904", "5501", "5502", "510"):
        assert poller.keep_alert(raw(rule_id, 7)) is False, rule_id


def test_low_level_alerts_are_dropped():
    assert poller.keep_alert(raw("1234", config.MIN_RULE_LEVEL - 1)) is False


def test_real_attack_alerts_are_kept():
    # our own agent rules and the genuine Wazuh findings must survive
    assert poller.keep_alert(raw("100102", 10)) is True   # installation agent
    assert poller.keep_alert(raw("100103", 12)) is True   # delivery agent
    assert poller.keep_alert(raw("5902", 8)) is True       # new user added
    assert poller.keep_alert(raw("5402", 3)) is True       # sudo to root (kept on purpose)


def test_our_agent_rules_are_never_in_the_denylist():
    assert not any(r.startswith("1001") for r in config.IGNORE_RULES)
