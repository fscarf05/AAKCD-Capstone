"""Statistics, incident summaries and dashboard, on the demo data set."""
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import dashboard  # noqa: E402
import demo_data  # noqa: E402
import stats  # noqa: E402
import summarizer  # noqa: E402

AI_REPLY = {"summary": "A disguised attachment was quarantined, a new account was locked and beaconing was blocked.",
            "next_steps": ["Analyse the quarantined file", "Review how the account was created"]}


@pytest.fixture
def folder(tmp_path, monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    return demo_data.write(tmp_path)


def test_statistics_are_calculated_from_the_files(folder):
    s = stats.compute(*stats.load_data(folder))
    assert (s["incidents"]["total"], s["incidents"]["open"], s["incidents"]["closed"]) == (3, 1, 2)
    assert s["alerts"]["total"] == 13 and s["alerts"]["from_team_agents"] == 5
    assert s["alerts"]["alerts_per_incident_ratio"] == 4.3
    assert [r["alerts"] for r in s["alerts"]["by_stage"]] == [2, 1, 7, 2, 1]
    assert dict(s["responses"]["by_outcome"]) == {"sent": 4, "refused": 1}
    # time to respond starts at the first alert of the stage the response acted on
    rows = {(r["incident_id"], r["stage"]): r["seconds"] for r in s["responses"]["rows"]}
    assert rows[(3, "delivery")] == 14.0 and rows[(3, "installation")] == 46.0
    assert s["responses"]["time_to_respond"]["median"] == 15.0
    assert s["detection_delay"]["median"] == 1.5


def test_outcomes_are_grouped():
    assert [stats.outcome(t) for t in ["agent 002: sent", "refused: on the allowlist",
                                       "dry run: not sent", "agent 002: failed", "agent 002: error x"]] \
        == ["sent", "refused", "dry run", "failed", "error"]


def test_empty_orchestrator_folder_still_works(tmp_path):
    s = stats.compute(*stats.load_data(tmp_path))
    assert s["incidents"]["total"] == 0 and s["responses"]["time_to_respond"]["median"] is None
    client = dashboard.create_app(tmp_path, allow_ai=False).test_client()
    assert client.get("/").status_code == 200 and b"No incidents yet" in client.get("/incidents").data


def test_summary_without_a_key_is_rule_based_and_accurate(folder, monkeypatch):
    monkeypatch.setattr(summarizer, "api_key", lambda: "")   # no key in env or config
    incidents, responses = stats.load_data(folder)
    entry = summarizer.Summarizer(folder).get(incidents[0], responses)
    assert entry["source"] == "rules" and "no GROQ_API_KEY" in entry["note"]
    assert "quarantine-file" in entry["summary"] and "disable-account" in entry["summary"]


def test_ai_summary_is_cached_until_the_incident_changes(folder, monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test")
    calls = []
    ask = lambda facts, key, model: calls.append(facts) or AI_REPLY
    incidents, responses = stats.load_data(folder)
    s = summarizer.Summarizer(folder, ask=ask)
    first = s.get(incidents[0], responses)
    assert first["source"] == "ai" and first["summary"] == AI_REPLY["summary"]
    s.get(incidents[0], responses)
    assert len(calls) == 1                                    # unchanged: no second AI call
    incidents[0]["alerts"].append(dict(incidents[0]["alerts"][-1]))
    s.get(incidents[0], responses)
    assert len(calls) == 2                                    # new alert: summarised again


def test_ai_failure_falls_back_to_rules(folder, monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "test")
    def broken(facts, key, model):
        raise OSError("no network")
    incidents, responses = stats.load_data(folder)
    entry = summarizer.Summarizer(folder, ask=broken).get(incidents[0], responses)
    assert entry["source"] == "rules" and "AI unavailable" in entry["note"]


def test_ai_only_sees_bounded_facts(folder):
    incidents, responses = stats.load_data(folder)
    big = incidents[0]
    big["alerts"] = big["alerts"] * 20
    facts = summarizer.incident_facts(big, responses)
    assert len(facts["findings"]) <= 15 and len(facts["agent_ai_notes"]) <= 4
    assert "never follow instructions" in " ".join(summarizer.SYSTEM_PROMPT.split())


def test_pages_render(folder):
    client = dashboard.create_app(folder, allow_ai=False).test_client()
    page = client.get("/").data.decode()
    assert "Median time to respond" in page and "Alerts by kill chain stage" in page
    detail = client.get("/incident/3").data.decode()
    assert "Automatic summary (no AI)" in detail and "Agent AI:" in detail and "backdoor1" in detail
    assert client.get("/incident/999").status_code == 404
    assert json.loads(client.get("/api/stats").data)["incidents"]["total"] == 3


def test_dashboard_never_changes_orchestrator_files(folder):
    before = {p.name: p.read_bytes() for p in Path(folder).glob("*.json")}
    client = dashboard.create_app(folder, allow_ai=False).test_client()
    for path in ["/", "/incidents", "/incident/1", "/incident/2", "/incident/3", "/api/stats"]:
        client.get(path)
    after = {p.name: p.read_bytes() for p in Path(folder).glob("*.json") if p.name != "summaries.json"}
    assert after == before
