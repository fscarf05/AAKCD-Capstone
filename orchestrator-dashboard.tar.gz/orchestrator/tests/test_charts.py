"""test_charts.py - the dashboard's SVG charts: shape, empty cases and, above
all, that attacker-chosen text (file names, commands, IPs) is HTML-escaped so
it cannot inject markup into the page.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import charts


def _alert(at, stage, summary="x", agent="recon"):
    return {"timestamp": f"2026-10-16T21:40:{at:02d}Z", "kill_chain_stage": stage,
            "source_agent": agent, "summary": summary, "confidence": "high"}


def _incident(iid, alerts, severity="high", value="victim"):
    return {"id": iid, "identifier_type": "host", "identifier_value": value,
            "alerts": alerts, "severity": severity}


def _row(iid, stage, command, target, seconds=10.0, outcome="sent", sent_at="2026-10-16T21:40:10Z"):
    return {"incident_id": iid, "stage": stage, "command": command, "target": target,
            "seconds": seconds, "outcome": outcome, "sent_at": sent_at}


# ---------------------------------------------------------------- stage mapping
def test_stage_maps_unknown_to_other():
    assert charts._stage("reconnaissance") == "reconnaissance"
    assert charts._stage("something-wazuh") == "other"
    assert charts._stage(None) == "other"


# ---------------------------------------------------------------- empty cases
def test_charts_are_none_when_there_is_nothing_to_draw():
    assert charts.activity([], []) is None
    assert charts.response_times([]) is None
    assert charts.incident_timeline(_incident(1, []), []) is None
    assert charts.grouping([]) == []


# ---------------------------------------------------------------- activity
def test_activity_returns_svg_legend_and_only_used_stages():
    incidents = [_incident(1, [_alert(0, "reconnaissance"), _alert(5, "exploitation")])]
    out = charts.activity(incidents, [])
    assert "<svg" in out["svg"] and "</svg>" in out["svg"]
    assert "s-reconnaissance" in out["svg"] and "s-exploitation" in out["svg"]
    # a stage with no alerts is left out of the legend
    assert "s-delivery" not in str(out["legend"])
    assert out["has_responses"] is False


def test_activity_draws_a_response_marker():
    incidents = [_incident(1, [_alert(0, "reconnaissance")])]
    responses = [{"time": "2026-10-16T21:40:02Z", "command": "firewall-drop",
                  "target": "10.0.0.9", "result": "agent 002: sent"}]
    out = charts.activity(incidents, responses)
    assert "class=\"marker\"" in out["svg"]
    assert out["has_responses"] is True


# ---------------------------------------------------------------- response times
def test_response_times_marks_the_median_and_mutes_refusals():
    rows = [_row(1, "reconnaissance", "firewall-drop", "10.0.0.9", seconds=12.0),
            _row(2, "exploitation", "firewall-drop", "10.0.0.1", seconds=30.0,
                 outcome="refused", sent_at="2026-10-16T21:41:10Z")]
    svg = charts.response_times(rows)
    assert "class=\"median\"" in svg          # at least one timed response -> median line
    assert "bar-muted" in svg                 # the refused one is drawn muted


# ---------------------------------------------------------------- grouping
def test_grouping_orders_by_size_and_scales_to_the_peak():
    incidents = [_incident(1, [_alert(0, "reconnaissance")]),
                 _incident(2, [_alert(0, "exploitation"), _alert(1, "exploitation"), _alert(2, "installation")])]
    rows = charts.grouping(incidents)
    assert [r["id"] for r in rows] == [2, 1]   # largest first
    assert rows[0]["alerts"] == 3 and rows[0]["pct"] == 100.0
    assert rows[1]["pct"] == round(100 / 3, 1)


def test_grouping_respects_the_limit():
    incidents = [_incident(i, [_alert(0, "reconnaissance")]) for i in range(20)]
    assert len(charts.grouping(incidents, limit=5)) == 5


# ---------------------------------------------------------------- incident timeline
def test_incident_timeline_has_a_lane_per_stage_and_a_response_diamond():
    incident = _incident(1, [_alert(0, "delivery"), _alert(5, "installation")])
    rows = [_row(1, "installation", "disable-account", "backdoor1", sent_at="2026-10-16T21:40:06Z")]
    svg = charts.incident_timeline(incident, rows)
    assert svg.count("class=\"dot") == 2          # one dot per alert
    assert "class=\"diamond\"" in svg             # the response
    assert "Delivery" in svg and "Installation" in svg


# ---------------------------------------------------------------- the safety property
def test_attacker_text_is_escaped_everywhere():
    nasty = "<script>alert(1)</script>"
    incident = _incident(1, [_alert(0, "delivery", summary=nasty, agent=nasty)], value=nasty)
    rows = [_row(1, "delivery", nasty, nasty, sent_at="2026-10-16T21:40:02Z")]
    responses = [{"time": "2026-10-16T21:40:02Z", "command": nasty, "target": nasty,
                  "result": "agent 002: sent"}]

    outputs = [charts.activity([incident], responses)["svg"],
               charts.response_times(rows),
               charts.incident_timeline(incident, rows)]
    for svg in outputs:
        assert "<script>" not in svg
        assert "&lt;script&gt;" in svg
