"""test_responder_safety.py - the orchestrator must never mass-block on a
false positive, and must never block the machines it protects.

Replays the 19 Oct incident: Tailscale's routine STUN checks to ~70 relay
servers looked like C2 beaconing, and recon read the same burst as the
victim scanning, so the old responder blocked 70 IPs and the victim's own IP.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config
import responder


def c2_alert(ip):
    return {"kill_chain_stage": "command_control", "evidence": {"destination_ip": ip}}


def incident(alerts, severity="critical"):
    return {"id": 7, "severity": severity, "alerts": alerts,
            "stages": sorted({a["kill_chain_stage"] for a in alerts}),
            "responded_stages": [], "skipped_stages": [], "responded_targets": []}


def test_fan_out_of_70_destinations_is_held_not_blocked():
    inc = incident([c2_alert(f"203.0.113.{n}") for n in range(1, 71)])
    assert responder.decide(inc) == []
    assert "command_control" in inc["held_stages"]


def test_a_real_c2_with_two_servers_is_still_blocked():
    inc = incident([c2_alert("203.0.113.44"), c2_alert("203.0.113.45")])
    targets = [a["value"] for a in responder.decide(inc)]
    assert targets == ["203.0.113.44", "203.0.113.45"]


def test_cap_counts_targets_already_blocked():
    # 5 already blocked earlier in this incident; a 6th must hold, not fire
    inc = incident([c2_alert(f"203.0.113.{n}") for n in range(1, 7)])
    inc["responded_targets"] = [f"block-outbound:203.0.113.{n}" for n in range(1, 6)]
    assert responder.decide(inc) == []


def test_victim_own_addresses_are_never_blocked():
    for ip in ("192.168.79.131", "100.82.83.1"):
        assert ip in config.ALLOWLIST
        assert responder._safety_check("firewall-drop", ip) is not None
        assert responder._safety_check("block-outbound", ip) is not None
