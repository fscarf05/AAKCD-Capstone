# config.py - lab settings for the AAKCD Response Orchestrator.
# Never commit this file to GitHub: it holds credentials.
# (config.py is listed in .gitignore.)

# --- Where Wazuh lives (your PC, over Tailscale) ---
WAZUH_HOST = "100.105.114.24"

INDEXER_URL = f"https://{WAZUH_HOST}:9200"   # where alerts are stored
INDEXER_USER = "admin"
INDEXER_PASS = "SecretPassword"

API_URL = f"https://{WAZUH_HOST}:55000"      # where responses are sent
API_USER = "wazuh-wui"
API_PASS = "MyS3cr37P450r.*-"

# --- Dashboard AI summaries (Groq) ---
# Used only by summarizer.py for plain-English incident summaries. Nothing in
# the orchestrator reads the summary, so this key never affects a response.
# The environment variable GROQ_API_KEY overrides this if set.
GROQ_API_KEY = "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"

# --- Polling ---
POLL_SECONDS = 15        # how often to check for new alerts
MIN_RULE_LEVEL = 3       # ignore Wazuh alerts below this level (routine noise)

# Noisy host-keeping Wazuh rules to drop before correlation, whatever their
# level. These fire on normal system activity and flood an incident without
# adding attack signal. A level filter alone misses the dpkg ones (they are
# level 7). Edit this list to tune; never add our own agent rules (100100+).
#   2901/2902/2904  dpkg: requested / installed / half-configured (apt churn)
#   5501/5502       PAM: login session opened / closed
#   510             rootcheck host-based anomaly (false-positive heavy)
# Sudo-to-root (5402) is kept in on purpose: repeated root escalation can matter.
IGNORE_RULES = {"2901", "2902", "2904", "5501", "5502", "510"}

# --- Correlation ---
TIME_WINDOW_MINUTES = 30 # alerts this close together can join one incident
REPEAT_THRESHOLD = 5     # this many alerts in one incident makes it "high"

# --- Response ---
# DRY_RUN = True means the orchestrator decides and logs responses but does
# NOT send them to Wazuh. Use it to test safely, then set it to False.
DRY_RUN = False

# Respond only to incidents at these severities.
RESPOND_AT = {"high", "critical"}

# Response scripts that actually exist on the victim machines.
# firewall-drop and disable-account ship with Wazuh; the others are our
# custom scripts in victim-scripts/, installed in
# /var/ossec/active-response/bin/ on each victim.
INSTALLED_RESPONSES = {"firewall-drop", "disable-account", "quarantine-file",
                       "kill-process", "block-outbound"}

# Never block these IPs, whatever the alerts say. Blocking the Wazuh
# server would cut the victim off from its own SIEM.
ALLOWLIST = {WAZUH_HOST}
# Never block the machines we protect: the victim's own addresses (LAN and Tailscale).
ALLOWLIST |= {"192.168.79.131", "100.82.83.1"}

# A real attacker uses a handful of servers, files or accounts. If one stage
# of one incident wants to act on more targets than this, hold it for an analyst.
MAX_TARGETS_PER_STAGE = 5
